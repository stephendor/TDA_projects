/*
 * Size.h
 *
 *  Created on: Dec 31, 2010
 *      Author: Vidit
 */

#ifndef SIZE_H_
#define SIZE_H_

typedef long num;
#define BANDIM -1;

#endif /* SIZE_H_ */
