/*
 * Global.h
 *
 *  Created on: Dec 31, 2010
 *      Author: Vidit
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

// combinatorial functions
# include "Combinatorics.h"
// debugging routines
# include "Debuggers.h"
// persistence flags!
# include "Pflags.h"

#endif /* GLOBAL_H_ */
